import styled from "styled-components";
import { Link } from "react-router-dom";

export const Nav = styled.div`
  background: #131519;
  width: 100%;
  height: 30px;
  margin-left: 50px;
  position: fixed;
  z-index: -1;
`;

export const MenuLateral = styled.div`
  background: #15171c;
  height: 100%;
  width: 50px;
  position: fixed;
  z-index: 1;
  display: flex;
  border-right: 2px solid #131519;
`;

export const Icons = styled(Link)`
  font-size: 1.7rem;
  margin: 0 auto;
  margin-top: 13px;
  height: 24px;
  color: darkgrey;

  &:hover {
    color: #fff;
  }
`;

export const DivIcon = styled.div`
  margin: 0 auto;
  margin-top: 13px;
  height: 24px;
  margin-left: 20px;
`;

export const SidebarNav = styled.nav`
  background-color: #131519;
  border-right: 2px solid #131519;
  width: 250px;
  height: 100%;
  display: flex;
  justify-content: center;
  position: fixed;
  top: 0;
  left: ${({ sidebar }) => (sidebar ? "50px" : "-100%")};
  transition: 550ms;
`;

export const SidebarWrap = styled.div`
  width: 100%;
`;
