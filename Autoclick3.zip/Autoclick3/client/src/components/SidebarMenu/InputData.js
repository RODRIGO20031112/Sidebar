import React, { useState } from "react";
import styled from "styled-components";

const Input = styled.input`
  border: none;
  outline: 0;
  background-color: transparent;
  font-size: 18px;
  color: #fff;
  caret-color: #fff;

  ::placeholder {
    color: rgba(255, 255, 255, 0.5);
  }
`;

export const InputQuest = () => {
  const [value, setValue] = useState("");

  function handleChange(event) {
    setValue(event.target.value);
  }

  return (
    <Input
      type="text"
      placeholder="Name Collection..."
      value={value}
      onChange={handleChange}
    />
  );
};
