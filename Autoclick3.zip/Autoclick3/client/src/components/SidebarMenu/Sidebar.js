import React, { useState } from "react";
// import * as FaIcons from "react-icons/fa";
// import * as AiIcons from "react-icons/ai";
import { SidebarData } from "./SidebarData";
import SubMenu from "./SubMenu";
// import { IconContext } from "react-icons/lib";
import * as VscIcons from "react-icons/vsc";

import {
  Nav,
  MenuLateral,
  Icons,
  // DivIcon,
  SidebarNav,
  SidebarWrap,
} from "./SidebarStyles";

const Sidebar = () => {
  const [sidebar, setSidebar] = useState(false);

  const showSidebar = () => setSidebar(!sidebar);

  return (
    <>
      <Nav>Isto é uma Nav</Nav>
      <MenuLateral>
        <Icons to="#">
          <VscIcons.VscFiles onClick={showSidebar} />
        </Icons>
      </MenuLateral>
      <SidebarNav sidebar={sidebar}>
        <SidebarWrap>
          {/* <DivIcon>
            <Icons to="#">
              <VscIcons.VscNewFolder />
            </Icons>
          </DivIcon> */}
          {SidebarData.map((item, index) => {
            return <SubMenu item={item} key={index} />;
          })}
        </SidebarWrap>
      </SidebarNav>
    </>
  );
};

export default Sidebar;
