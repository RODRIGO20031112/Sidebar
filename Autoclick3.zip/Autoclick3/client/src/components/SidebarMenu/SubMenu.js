import React, { useState } from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";

const SidebarLink = styled(Link)`
  display: flex;
  color: #e1e9fc;
  padding: 20px;
  list-style: none;
  height: 60px;
  text-decoration: none;
  font-size: 18px;

  &:hover {
    background: #252831;
    border-left: 2px solid #fff;
    cursor: pointer;
  }

  &:nth-child(1) {
    border-bottom: 2px solid #131519;
    border-left: 0px;
    height: 30px;
    background: #15171c;
  }
`;

const Div = styled.div`
  display: flex;
  align-items: center;
`;

const SidebarIcons = styled.div`
  width: 18px;
  height: 18px;
  align-itens: center;
`;

const ArrowIcons = styled.div`
  width: 18px;
  height: 18px;
  align-itens: center;
  position: absolute;
  right: 22px;
`;

const SidebarLabel = styled.span`
  margin-left: 16px;
`;

const DropdownLink = styled(Link)`
  background: #1f222a;
  height: 60px;
  padding-left: 3rem;
  display: flex;
  align-items: center;
  text-decoration: none;
  color: #f5f5f5;
  font-size: 18px;

  &:hover {
    background: #252831;
    cursor: pointer;
  }

  &:nth-child(2) {
    border-bottom: 2px solid #131519;
    padding: 20px;
    height: 30px;
  }
`;

const SubMenu = ({ item }) => {
  const [subnav, setSubnav] = useState(false);

  const showSubnav = () => setSubnav(!subnav);

  return (
    <>
      <SidebarLink to={item.path} onClick={item.subNav && showSubnav}>
        <Div>
          <SidebarIcons>{item.icon}</SidebarIcons>
          <SidebarLabel>{item.title}</SidebarLabel>

          <ArrowIcons>
            {item.subNav && subnav
              ? item.iconOpened
              : item.subNav
              ? item.iconClosed
              : null}
          </ArrowIcons>
        </Div>
      </SidebarLink>
      {subnav &&
        item.subNav.map((item, index) => {
          return (
            <DropdownLink to={item.path} key={index}>
              {item.icon}
              <SidebarLabel>{item.title}</SidebarLabel>
            </DropdownLink>
          );
        })}
    </>
  );
};

export default SubMenu;
