import "./App.css";
import Switch from "./Routes/Routes";

function App() {
  return <Switch />;
}

export default App;
